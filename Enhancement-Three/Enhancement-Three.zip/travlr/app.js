const express = require('express');
const path = require('path');
const hbs = require('hbs');

require('dotenv').config();
require('./app_api/models/db');

const passport = require('passport');
require('./app_api/config/passport');

const app = express();

const apiRouter = require('./app_api/routes/index');
const routes = require('./app_server/routes/index');

app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

hbs.registerPartials(
  path.join(__dirname, 'app_server', 'views', 'partials')
);

app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

// Body parsing
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// CORS for Angular
app.use('/api', (req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );
  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, PUT, DELETE'
  );
  next();
});

// API routes
app.use('/api', apiRouter);

// Server-rendered routes
app.use('/', routes);

// Catch unauthorized errors
app.use((err, req, res, next) => {
  if (err.name === 'UnauthorizedError') {
    res.status(401).json({
      message: err.name + ': ' + err.message
    });
  }
});

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});