import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { Trip } from '../models/trip';
import { TripCard } from '../trip-card/trip-card';
import {
  TripDataService
} from '../services/trip-data';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [
    CommonModule,
    FormsModule,
    TripCard
  ],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit, OnDestroy {

  trips: Trip[] = [];

  message = 'Loading trips...';

  loggedIn = false;

  searchTerm = '';

  sortField = 'name';

  sortDirection = 'asc';

  currentPage = 1;

  totalPages = 1;

  readonly pageSize = 5;

  private authenticationSubscription?: Subscription;

  constructor(
    private tripDataService: TripDataService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {

    this.authenticationSubscription =
      this.authenticationService.loggedIn$
        .subscribe((loggedIn: boolean) => {

          this.loggedIn = loggedIn;

          this.changeDetectorRef.detectChanges();

        });

    this.loadTrips();

  }

  ngOnDestroy(): void {
    this.authenticationSubscription?.unsubscribe();
  }

  public addTrip(): void {

    if (!this.loggedIn) {
      this.router.navigate(['login']);
      return;
    }

    this.router.navigate(['add-trip']);

  }

  public isLoggedIn(): boolean {
    return this.loggedIn;
  }

  public searchTrips(): void {

    this.currentPage = 1;

    this.loadTrips();

  }

  public sortTrips(): void {

    this.currentPage = 1;

    this.loadTrips();

  }

  public nextPage(): void {

    if (this.currentPage < this.totalPages) {

      this.currentPage++;

      this.loadTrips();

    }

  }

  public previousPage(): void {

    if (this.currentPage > 1) {

      this.currentPage--;

      this.loadTrips();

    }

  }

  private loadTrips(): void {

    this.tripDataService.getTrips(
      this.searchTerm,
      this.sortField,
      this.sortDirection,
      this.currentPage,
      this.pageSize
    )
    .subscribe({

      next: (response: any) => {

        console.log('FULL RESPONSE:', response);

        this.trips = response.trips ?? [];

        this.currentPage = response.page ?? 1;

        this.totalPages = response.totalPages ?? 1;

        this.message =
          `Showing ${this.trips.length} of ${response.totalResults ?? 0} trips`;

        this.changeDetectorRef.detectChanges();

      },

      error: (error: any) => {

        console.error('TRIP API ERROR:', error);

        this.message =
          'The trips could not be loaded. Please try again.';

        this.changeDetectorRef.detectChanges();

      }

    });

  }

}