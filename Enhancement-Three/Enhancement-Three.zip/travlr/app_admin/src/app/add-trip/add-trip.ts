import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-add-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip {

  formData = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  errorMessage = '';
  successMessage = '';
  isSubmitting = false;

  constructor(
    private tripDataService: TripDataService,
    private router: Router
  ) {}

  private isFormValid(): boolean {
    return Object.values(this.formData).every((value) =>
      String(value).trim() !== ''
    );
  }

  private getErrorMessage(error: HttpErrorResponse): string {
    if (error.status === 0) {
      return 'Unable to connect to the server. Please try again.';
    }

    if (error.error?.message) {
      return error.error.message;
    }

    return 'The trip could not be added. Please check the form and try again.';
  }

  onSubmit(): void {
    this.errorMessage = '';
    this.successMessage = '';

    if (!this.isFormValid()) {
      this.errorMessage = 'Please complete all required trip fields.';
      return;
    }

    this.isSubmitting = true;

    this.tripDataService.addTrip(this.formData as any)
      .subscribe({
        next: () => {
          this.isSubmitting = false;
          this.successMessage = 'Trip added successfully.';

          this.router.navigate(['']);
        },
        error: (error: HttpErrorResponse) => {
          this.isSubmitting = false;
          this.errorMessage = this.getErrorMessage(error);
        }
      });
  }
}