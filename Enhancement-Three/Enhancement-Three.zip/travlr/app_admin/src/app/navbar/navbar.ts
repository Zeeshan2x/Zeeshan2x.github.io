import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import {
  Router,
  RouterModule
} from '@angular/router';

import { Subscription } from 'rxjs';

import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-navbar',
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar implements OnInit, OnDestroy {

  loggedIn = false;

  private authenticationSubscription?: Subscription;

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.authenticationSubscription =
      this.authenticationService.loggedIn$
        .subscribe((loggedIn: boolean) => {
          this.loggedIn = loggedIn;
          this.changeDetectorRef.detectChanges();
        });
  }

  ngOnDestroy(): void {
    this.authenticationSubscription?.unsubscribe();
  }

  public isLoggedIn(): boolean {
    return this.loggedIn;
  }

  public onLogout(): void {
    this.authenticationService.logout();
    this.router.navigate(['']);
  }
}