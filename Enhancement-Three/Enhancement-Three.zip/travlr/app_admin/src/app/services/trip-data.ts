import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';

interface TripMutationResponse {
  message: string;
  trip: Trip;
}

export interface TripListResponse {
  trips: Trip[];
  page: number;
  totalPages: number;
  totalResults: number;
}

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private readonly apiBaseUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  public getTrips(
    search: string = '',
    sort: string = 'name',
    direction: string = 'asc',
    page: number = 1,
    limit: number = 5
  ): Observable<TripListResponse> {

    const params = new HttpParams()
      .set('search', search)
      .set('sort', sort)
      .set('direction', direction)
      .set('page', page)
      .set('limit', limit);

    return this.http.get<TripListResponse>(
      `${this.apiBaseUrl}/trips`,
      { params }
    );
  }

  public getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(
      `${this.apiBaseUrl}/trips/${tripCode}`
    );
  }

  public addTrip(
    formData: Trip
  ): Observable<TripMutationResponse> {
    return this.http.post<TripMutationResponse>(
      `${this.apiBaseUrl}/trips`,
      formData
    );
  }

  public updateTrip(
    formData: Trip
  ): Observable<TripMutationResponse> {
    return this.http.put<TripMutationResponse>(
      `${this.apiBaseUrl}/trips/${formData.code}`,
      formData
    );
  }

  public login(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    return this.handleAuthAPICall(
      'login',
      user,
      passwd
    );
  }

  public register(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    return this.handleAuthAPICall(
      'register',
      user,
      passwd
    );
  }

  private handleAuthAPICall(
    endpoint: string,
    user: User,
    passwd: string
  ): Observable<AuthResponse> {

    const formData = {
      name: user.name,
      email: user.email,
      password: passwd
    };

    return this.http.post<AuthResponse>(
      `${this.apiBaseUrl}/${endpoint}`,
      formData
    );
  }
}