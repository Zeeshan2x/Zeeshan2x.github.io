import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';

import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';

import { TripDataService } from './trip-data';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private readonly loggedInSubject: BehaviorSubject<boolean>;

  public readonly loggedIn$: Observable<boolean>;

  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripDataService: TripDataService
  ) {
    this.loggedInSubject =
      new BehaviorSubject<boolean>(this.hasValidToken());

    this.loggedIn$ =
      this.loggedInSubject.asObservable();
  }

  public getToken(): string {
    return this.storage.getItem('travlr-token') ?? '';
  }

  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
    this.loggedInSubject.next(true);
  }

  public logout(): void {
    this.storage.removeItem('travlr-token');
    this.loggedInSubject.next(false);
  }

  public isLoggedIn(): boolean {
    const loggedIn = this.hasValidToken();

    if (!loggedIn && this.getToken()) {
      this.storage.removeItem('travlr-token');
      this.loggedInSubject.next(false);
    }

    return loggedIn;
  }

  public getCurrentUser(): User | null {
    const token = this.getToken();

    if (!token) {
      return null;
    }

    try {
      const payload =
        JSON.parse(atob(token.split('.')[1]));

      return {
        email: payload.email,
        name: payload.name
      } as User;
    } catch {
      this.logout();
      return null;
    }
  }

  public login(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    return this.tripDataService.login(user, passwd)
      .pipe(
        tap((response: AuthResponse) => {
          this.saveToken(response.token);
        })
      );
  }

  public register(
    user: User,
    passwd: string
  ): Observable<AuthResponse> {
    return this.tripDataService.register(user, passwd)
      .pipe(
        tap((response: AuthResponse) => {
          this.saveToken(response.token);
        })
      );
  }

  private hasValidToken(): boolean {
    const token =
      this.storage.getItem('travlr-token') ?? '';

    if (!token) {
      return false;
    }

    try {
      const payload =
        JSON.parse(atob(token.split('.')[1]));

      return payload.exp > Date.now() / 1000;
    } catch {
      return false;
    }
  }
}