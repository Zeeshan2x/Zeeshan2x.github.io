import {
  ChangeDetectorRef,
  Component,
  Input,
  OnDestroy,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { Trip } from '../models/trip';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-card',
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css'
})
export class TripCard implements OnInit, OnDestroy {

  @Input() trip!: Trip;

  loggedIn = false;

  private authenticationSubscription?: Subscription;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.authenticationSubscription =
      this.authenticationService.loggedIn$
        .subscribe((loggedIn: boolean) => {
          this.loggedIn = loggedIn;
          this.changeDetectorRef.detectChanges();
        });
  }

  ngOnDestroy(): void {
    this.authenticationSubscription?.unsubscribe();
  }

  public editTrip(trip: Trip): void {
    if (!this.loggedIn) {
      this.router.navigate(['login']);
      return;
    }

    localStorage.setItem('tripCode', trip.code);
    this.router.navigate(['edit-trip']);
  }

  public isLoggedIn(): boolean {
    return this.loggedIn;
  }
}