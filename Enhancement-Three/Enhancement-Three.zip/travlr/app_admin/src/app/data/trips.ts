export const trips = [
  {
    code: 'GR01',
    name: 'Gale Reef',
    length: '7 nights',
    start: '2026-06-15',
    resort: 'Ocean Paradise Resort',
    perPerson: '1299',
    image: 'reef1.jpg',
    description: 'Gale Reef is known for colorful coral reefs, diving spots, and clear blue water.'
  },
  {
    code: 'DR02',
    name: "Dawson's Reef",
    length: '5 nights',
    start: '2026-07-01',
    resort: 'Tropical Escape Resort',
    perPerson: '999',
    image: 'reef2.jpg',
    description: "Dawson's Reef offers relaxing beaches, tropical scenery, and guided snorkeling tours."
  },
  {
    code: 'CR03',
    name: "Claire's Reef",
    length: '10 nights',
    start: '2026-08-10',
    resort: 'Coral View Resort',
    perPerson: '1599',
    image: 'reef3.jpg',
    description: "Claire's Reef features crystal clear water, marine life, and underwater sightseeing activities."
  }
];