import {
  ChangeDetectorRef,
  Component
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { AuthenticationService } from '../services/authentication';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {

  formError = '';
  isSubmitting = false;

  credentials = {
    email: '',
    password: ''
  };

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  public onLoginSubmit(): void {
    this.formError = '';

    if (
      !this.credentials.email.trim() ||
      !this.credentials.password.trim()
    ) {
      this.formError =
        'Email and password are required. Please try again.';

      this.changeDetectorRef.detectChanges();
      return;
    }

    this.isSubmitting = true;
    this.changeDetectorRef.detectChanges();

    const user = {
      email: this.credentials.email.trim(),
      name: ''
    } as User;

    this.authenticationService.login(
      user,
      this.credentials.password
    )
      .subscribe({
        next: () => {
          this.isSubmitting = false;
          this.changeDetectorRef.detectChanges();
          this.router.navigate(['']);
        },
        error: (error: HttpErrorResponse) => {
          this.isSubmitting = false;
          this.formError = this.getLoginError(error);
          this.changeDetectorRef.detectChanges();
        }
      });
  }

  private getLoginError(
    error: HttpErrorResponse
  ): string {
    if (error.status === 0) {
      return 'Unable to connect to the server. Please try again.';
    }

    if (error.status === 401) {
      return error.error?.message ||
        'The email or password is incorrect.';
    }

    if (error.error?.message) {
      return error.error.message;
    }

    return 'Login failed. Please try again.';
  }
}