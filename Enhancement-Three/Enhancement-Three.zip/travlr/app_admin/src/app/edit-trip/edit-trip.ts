import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {

  formData: any = {};

  errorMessage = '';
  successMessage = '';
  isLoading = true;
  isSubmitting = false;

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const tripCode = localStorage.getItem('tripCode');

    if (!tripCode) {
      this.errorMessage = 'No trip was selected for editing.';
      this.isLoading = false;
      this.changeDetectorRef.detectChanges();

      setTimeout(() => {
        this.router.navigate(['']);
      }, 1500);

      return;
    }

    this.tripDataService.getTrip(tripCode)
      .subscribe({
        next: (trip: Trip) => {
          this.formData = {
            ...trip,
            start: this.formatDateForInput(trip.start)
          };

          this.isLoading = false;
          this.changeDetectorRef.detectChanges();
        },
        error: (error: HttpErrorResponse) => {
          this.isLoading = false;
          this.errorMessage = this.getErrorMessage(
            error,
            'The selected trip could not be loaded.'
          );

          this.changeDetectorRef.detectChanges();
        }
      });
  }

  private formatDateForInput(dateValue: any): string {
    if (!dateValue) {
      return '';
    }

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
      return '';
    }

    return date.toISOString().split('T')[0];
  }

  private isFormValid(): boolean {
    const requiredFields = [
      'code',
      'name',
      'length',
      'start',
      'resort',
      'perPerson',
      'image',
      'description'
    ];

    return requiredFields.every((field) =>
      String(this.formData[field] ?? '').trim() !== ''
    );
  }

  private getErrorMessage(
    error: HttpErrorResponse,
    fallbackMessage: string
  ): string {
    if (error.status === 0) {
      return 'Unable to connect to the server. Please try again.';
    }

    if (error.status === 401) {
      return 'Your session is invalid or has expired. Please log in again.';
    }

    if (error.error?.message) {
      return error.error.message;
    }

    return fallbackMessage;
  }

  onSubmit(): void {
    this.errorMessage = '';
    this.successMessage = '';

    if (!this.isFormValid()) {
      this.errorMessage = 'Please complete all required trip fields.';
      this.changeDetectorRef.detectChanges();
      return;
    }

    this.isSubmitting = true;
    this.changeDetectorRef.detectChanges();

    this.tripDataService.updateTrip(this.formData)
      .subscribe({
        next: () => {
          this.isSubmitting = false;
          this.successMessage = 'Trip updated successfully.';

          localStorage.removeItem('tripCode');
          this.changeDetectorRef.detectChanges();

          setTimeout(() => {
            this.router.navigate(['']);
          }, 800);
        },
        error: (error: HttpErrorResponse) => {
          this.isSubmitting = false;
          this.errorMessage = this.getErrorMessage(
            error,
            'The trip could not be updated. Please check the form and try again.'
          );

          this.changeDetectorRef.detectChanges();
        }
      });
  }
}