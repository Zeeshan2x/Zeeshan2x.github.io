const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
    // Get the Authorization header
    const authHeader = req.headers.authorization;

    // Verify the header exists and starts with "Bearer "
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({
            message: 'Authorization token is required.'
        });
    }

    // Extract the token
    const token = authHeader.split(' ')[1];

    try {
        // Verify the token using the application's JWT secret
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Store decoded user information for later use
        req.user = decoded;

        next();
    } catch (err) {
        return res.status(401).json({
            message: 'Invalid or expired authorization token.'
        });
    }
};

module.exports = auth;