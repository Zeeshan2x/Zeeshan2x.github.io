const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      unique: true,
      index: true,
      uppercase: true,
      trim: true,
      minlength: 2,
      maxlength: 10
    },

    name: {
      type: String,
      required: true,
      index: true,
      trim: true,
      minlength: 2,
      maxlength: 100
    },

    length: {
      type: String,
      required: true,
      trim: true
    },

    start: {
      type: Date,
      required: true,
      index: true
    },

    resort: {
      type: String,
      required: true,
      index: true,
      trim: true,
      minlength: 2,
      maxlength: 100
    },

    perPerson: {
      type: String,
      required: true,
      trim: true
    },

    image: {
      type: String,
      required: true,
      trim: true
    },

    description: {
      type: String,
      required: true,
      trim: true,
      minlength: 5,
      maxlength: 1000
    }
  },
  {
    timestamps: true
  }
);

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;