const mongoose = require('./db');
const fs = require('fs');
const Trip = require('./travlr');

const trips = JSON.parse(
    fs.readFileSync('./data/trips.json', 'utf8')
);

Trip.deleteMany({})
    .then(() => {
        return Trip.insertMany(trips);
    })
    .then(() => {
        console.log('Database successfully seeded');
        mongoose.connection.close();
    })
    .catch(err => {
        console.log(err);
        mongoose.connection.close();
    });