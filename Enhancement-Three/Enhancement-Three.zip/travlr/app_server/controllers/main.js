const tripsEndpoint = 'http://localhost:3000/api/trips';

const options = {
    method: 'GET',
    headers: {
        'Accept': 'application/json'
    }
};

const travel = async (req, res) => {
    await fetch(tripsEndpoint, options)
        .then(res => res.json())
        .then(json => {
            if (!Array.isArray(json)) {
                throw new Error('API response was not an array');
            }

            if (json.length === 0) {
                throw new Error('No trips exist in database');
            }

            res.render('travel', {
                title: 'Travlr Getaways',
                trips: json
            });
        })
        .catch(err => res.status(500).send(err.message));
};

module.exports = {
    travel
};