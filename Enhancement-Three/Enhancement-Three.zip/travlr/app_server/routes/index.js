const express = require('express');
const router = express.Router();

const ctrlMain = require('../controllers/main');

router.get('/', ctrlMain.travel);
router.get('/travel', ctrlMain.travel);

module.exports = router;