import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { Trip } from '../models/trip';
import { TripCard } from '../trip-card/trip-card';
import { TripDataService } from '../services/trip-data';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit, OnDestroy {

  trips: Trip[] = [];
  message = 'Loading trips...';
  loggedIn = false;

  private authenticationSubscription?: Subscription;

  constructor(
    private tripDataService: TripDataService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.authenticationSubscription =
      this.authenticationService.loggedIn$
        .subscribe((loggedIn: boolean) => {
          this.loggedIn = loggedIn;
          this.changeDetectorRef.detectChanges();
        });

    this.getTrips();
  }

  ngOnDestroy(): void {
    this.authenticationSubscription?.unsubscribe();
  }

  public addTrip(): void {
    if (!this.loggedIn) {
      this.router.navigate(['login']);
      return;
    }

    this.router.navigate(['add-trip']);
  }

  public isLoggedIn(): boolean {
    return this.loggedIn;
  }

  private getTrips(): void {
    this.tripDataService.getTrips()
      .subscribe({
        next: (trips: Trip[]) => {
          this.trips = trips;
          this.message =
            `There are ${trips.length} trips available.`;

          this.changeDetectorRef.detectChanges();
        },
        error: () => {
          this.message =
            'The trips could not be loaded. Please try again.';

          this.changeDetectorRef.detectChanges();
        }
      });
  }
}