const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const requiredTripFields = [
  'code',
  'name',
  'length',
  'start',
  'resort',
  'perPerson',
  'image',
  'description'
];

const validateTripRequest = (body) => {
  const missingFields = requiredTripFields.filter((field) => {
    const value = body[field];

    return value === undefined ||
      value === null ||
      String(value).trim() === '';
  });

  if (missingFields.length > 0) {
    return {
      valid: false,
      message: `Missing required fields: ${missingFields.join(', ')}`
    };
  }

  if (Number.isNaN(Date.parse(body.start))) {
    return {
      valid: false,
      message: 'Start date must be a valid date.'
    };
  }

  return {
    valid: true
  };
};

const buildTripData = (body) => ({
  code: String(body.code).trim().toUpperCase(),
  name: String(body.name).trim(),
  length: String(body.length).trim(),
  start: body.start,
  resort: String(body.resort).trim(),
  perPerson: String(body.perPerson).trim(),
  image: String(body.image).trim(),
  description: String(body.description).trim()
});

const sendServerError = (res, err) => {
  console.error(err);

  return res.status(500).json({
    message: 'An unexpected server error occurred.'
  });
};

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({});

    if (!trips || trips.length === 0) {
      return res.status(404).json({
        message: 'No trips found.'
      });
    }

    return res.status(200).json(trips);
  } catch (err) {
    return sendServerError(res, err);
  }
};

const tripsFindByCode = async (req, res) => {
  try {
    const tripCode = String(req.params.tripCode).trim().toUpperCase();

    const trip = await Trip.findOne({
      code: tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return sendServerError(res, err);
  }
};

const tripsAddTrip = async (req, res) => {
  const validationResult = validateTripRequest(req.body);

  if (!validationResult.valid) {
    return res.status(400).json({
      message: validationResult.message
    });
  }

  try {
    const tripData = buildTripData(req.body);

    const existingTrip = await Trip.findOne({
      code: tripData.code
    });

    if (existingTrip) {
      return res.status(409).json({
        message: `A trip with the code ${tripData.code} already exists.`
      });
    }

    const newTrip = await Trip.create(tripData);

    return res.status(201).json({
      message: 'Trip created successfully.',
      trip: newTrip
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: 'Trip validation failed.',
        errors: Object.values(err.errors).map((error) => error.message)
      });
    }

    return sendServerError(res, err);
  }
};

const tripsUpdateTrip = async (req, res) => {
  const validationResult = validateTripRequest(req.body);

  if (!validationResult.valid) {
    return res.status(400).json({
      message: validationResult.message
    });
  }

  try {
    const currentTripCode =
      String(req.params.tripCode).trim().toUpperCase();

    const tripData = buildTripData(req.body);

    if (tripData.code !== currentTripCode) {
      const duplicateTrip = await Trip.findOne({
        code: tripData.code
      });

      if (duplicateTrip) {
        return res.status(409).json({
          message: `A trip with the code ${tripData.code} already exists.`
        });
      }
    }

    const updatedTrip = await Trip.findOneAndUpdate(
      {
        code: currentTripCode
      },
      tripData,
      {
        new: true,
        runValidators: true
      }
    );

    if (!updatedTrip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    return res.status(200).json({
      message: 'Trip updated successfully.',
      trip: updatedTrip
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      return res.status(400).json({
        message: 'Trip validation failed.',
        errors: Object.values(err.errors).map((error) => error.message)
      });
    }

    return sendServerError(res, err);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip
};