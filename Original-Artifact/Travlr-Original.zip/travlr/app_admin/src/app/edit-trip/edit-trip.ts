import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {

  formData: any = {};

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const tripCode = localStorage.getItem('tripCode');

    if (!tripCode) {
      alert('No trip selected');
      this.router.navigate(['']);
      return;
    }

    this.tripDataService.getTrip(tripCode)
      .subscribe({
        next: (trip: Trip) => {
          console.log('EDIT TRIP DATA:', trip);
          this.formData = trip;
          this.changeDetectorRef.detectChanges();
        },
        error: (err) => {
          console.error(err);
        }
      });
  }

  onSubmit(): void {
    this.tripDataService.updateTrip(this.formData)
      .subscribe({
        next: () => {
          this.router.navigate(['']);
        },
        error: (err) => {
          console.error(err);
        }
      });
  }
}