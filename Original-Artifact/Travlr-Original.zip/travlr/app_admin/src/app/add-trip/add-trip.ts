import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-add-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip {

  formData = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(
    private tripDataService: TripDataService,
    private router: Router
  ) {}

onSubmit(): void {
  console.log('FORM DATA BEING SENT:', this.formData);

  this.tripDataService.addTrip(this.formData as any)
    .subscribe({
      next: () => {
        this.router.navigate(['']);
      },
      error: (err) => {
        console.error('ADD TRIP ERROR:', err);
      }
    });
}
}