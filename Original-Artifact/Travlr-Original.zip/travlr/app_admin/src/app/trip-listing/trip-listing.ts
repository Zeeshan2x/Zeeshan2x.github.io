import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { Trip } from '../models/trip';
import { TripCard } from '../trip-card/trip-card';
import { TripDataService } from '../services/trip-data';
import { AuthenticationService } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit {

  trips: Trip[] = [];
  message: string = 'Loading trips...';

  constructor(
    private tripDataService: TripDataService,
    private changeDetectorRef: ChangeDetectorRef,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    console.log('trip-listing constructor');
  }

  ngOnInit(): void {
    console.log('ngOnInit');
    this.getStuff();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  private getStuff(): void {
    this.tripDataService.getTrips()
      .subscribe({
        next: (value: Trip[]) => {
          console.log('API VALUE:', value);
          this.trips = value;
          this.message = 'There are ' + value.length + ' trips available.';
          this.changeDetectorRef.detectChanges();
        },
        error: (error: any) => {
          console.log('API ERROR:', error);
          this.message = 'Error loading trips';
          this.changeDetectorRef.detectChanges();
        }
      });
  }
}